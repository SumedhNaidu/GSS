﻿using Microsoft.EntityFrameworkCore;
using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;

namespace Models.Context
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext(DbContextOptions<ProductDbContext> options) : base(options)
        {

        }
        public DbSet<Product> Products { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Product>()
                .Property(p => p.Price)
                .HasColumnType("decimal(18,2)");
            modelBuilder.Entity<Product>()
                .HasIndex(p => p.Name);
            //    modelBuilder.Entity<Product>()
            //        .Property(p => p.Id)
            //        .ValueGeneratedOnAdd();
            //    _ = modelBuilder.Entity<Product>().HasData(
            //        new Product
            //        {
            //            Id = 1,
            //            Name = "Laptop",
            //            Description = "High-Performance",
            //            Price = 1200.50,
            //            StockQuantity = 10,
            //            CreatedAt = DateTime.UtcNow,
            //            UpdatedAt = DateTime.UtcNow
            //        },
            //        new Product
            //        {
            //            Id = 2,
            //            Name = "Dell",
            //            Description = "Compatible",
            //            Price = 1201.50,
            //            StockQuantity = 11,
            //            CreatedAt = DateTime.UtcNow,
            //            UpdatedAt = DateTime.UtcNow
            //        });
        }
    }
}
