﻿using Models.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViewModels.ViewModels;

namespace Interfaces.Interfaces
{
    public interface IProductService
    {
        public ProductDto GetProductById(int id);
        public IEnumerable<Product> GetAllProducts(string name, int page, int pageSize);
        public ResponseDto CreateProduct(CreateProductDto productDto);
        public UpdateProductDto UpdateProduct(UpdateProductDto productDto);
        public void DeleteProduct(int id);
    }
}
