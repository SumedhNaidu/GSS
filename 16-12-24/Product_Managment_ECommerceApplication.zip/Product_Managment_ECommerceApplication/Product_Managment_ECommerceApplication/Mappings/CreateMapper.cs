﻿using AutoMapper;
using Models.Models;
using ViewModels.ViewModels;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace Product_Managment_API.Mappings
{
    public class CreateMapper : Profile
    {
        public CreateMapper()
        {
            CreateMap<Product, CreateProductDto>().ReverseMap();

            CreateMap<ResponseDto, CreateProductDto>().ReverseMap();
        }
    }
}
