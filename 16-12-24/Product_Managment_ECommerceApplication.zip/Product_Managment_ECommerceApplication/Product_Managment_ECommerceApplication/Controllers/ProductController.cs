﻿using Interfaces.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Models.Context;
using ViewModels.ViewModels;

namespace Product_Managment_API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductService _productService;
        public ProductsController(IProductService productService)
        {
            _productService = productService;
        }
        [HttpGet]
        [Route("GetProducts")]
        public IActionResult GetProducts(string name, [FromQuery] int page = 1, [FromQuery] int pageSize = 10)
        {
            try
            {
                var products = _productService.GetAllProducts(name, page, pageSize);
                return Ok(products);
            }
            catch (Exception ex)
            {
                return BadRequest($"An error occured: {ex.Message}");
            }
        }
        [HttpGet]
        [Route("GetProduct/{id}")]
        public IActionResult GetProduct(int id)
        {
            try
            {
                var product = _productService.GetProductById(id);
                if (product == null)
                {
                    return NotFound("Product not found");
                }
                return Ok(product);
            }
            catch (Exception ex)
            {
                return BadRequest($"An error occured:{ex.Message}");
            }
        }
        [HttpPost]
        [Route("Create")]
        public IActionResult CreateProduct([FromBody] CreateProductDto productDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var createdProduct = _productService.CreateProduct(productDto);
                return CreatedAtAction(
                    nameof(GetProduct),
                    new { id = createdProduct.Success },
                    createdProduct);
            }
            catch (Exception ex)
            {
                return BadRequest($"An error occured: {ex.Message}");
            }
        }
        [HttpPut]
        [Route("Update/{id}")]
        public IActionResult UpdateProduct(int id, [FromBody] UpdateProductDto productDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }
                var updatedProduct = _productService.UpdateProduct(productDto);
                if (updatedProduct == null)
                {
                    return NotFound("Product not found or update failed");
                }
                return Ok(updatedProduct);
            }
            catch (Exception ex)
            {
                return BadRequest($"An error occured: {ex.Message}");
            }
        }
        [HttpDelete]
        [Route("Delete/{id}")]
        public IActionResult DeleteProduct(int id)
        {
            try
            {
                _productService.DeleteProduct(id);
                if (id == null)
                {
                    return NotFound("Product not found or deletion failed .");
                }
                return Ok("Product deleted successfully");
            }
            catch (Exception ex)
            {
                return BadRequest($"An error occurred:{ex.Message}");
            }
        }
    }
}
